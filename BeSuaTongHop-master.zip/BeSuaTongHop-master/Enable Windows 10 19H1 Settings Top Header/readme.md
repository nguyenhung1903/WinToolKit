# Cách bật thanh trạng thái ở trong Windows 10 19H1 Settings

Năm 2019, sau khi Microsoft tung ra bản 19H1, Microsoft tiếp tục tập trung vào giao diện mới của Windows Settings trong các bản update sau. Tuy vậy, đến bây giờ nhiều người vẫn ở 1903 mà không muốn update lên 1909 hay là 2004. Nhưng đừng lo, dưới đây là cách bật thanh trạng thái của Windows 10 19H1 Settings.

Bước 1: Truy cập link dưới tải file về và giải nén ra(32bit chọn x86, 64bit chọn x64)

Link Download: [Download Now](https://github.com/riverar/mach2/releases)

Bước 2: Mở CMD với quyền Administrator, nhập cd {Đường dẫn chứa file} rồi Enter

VD: cd C:\Users\BeSua\Downloads\mach2_0.3.0.0_x64

Bước 3: Nhập lần lượt các lệnh sau

* mach2 enable 18299130
* mach2 enable 19638738
* mach2 enable 19638787
* mach2 enable 18863954

# Chú ý nếu nó không tác dụng, là do bạn:

* Đang sử dụng bản Enterprise
* Sử dụng 1 phiên bản không có Windows Spotlight
* Đang ở trong Safe Mode
* Đăng nhập tài khoản Khách
* Đang ở trong các khu vực trong danh sách đen

![Image](https://news-cdn.softpedia.com/images/news2/how-to-try-out-the-new-settings-ui-in-windows-10-19h1-524432-3.jpg)
