# Cách hiển thị giây trên đồng hồ ở Windows 10

Cái này cũng không có nói gì nhiều, nói dung dành cho ai thích nhìn giây. Sau đây là cách bật.

Các bạn chỉ cần tải file dưới về chạy rồi khởi động lại máy là xong.

Link Download Add (Cho ai muốn hiển thị): [Download Now](https://www.upload.ee/files/12105994/Show_Seconds_In_System_Clock.reg.html)

Link Download Remove (Cho ai muốn gỡ): [Download Now](https://www.upload.ee/files/12105995/Remove_Seconds_From_System_Clock.reg.html)

![Image](https://www.howtogeek.com/wp-content/uploads/2017/09/ximg_59b19965e3ea1.png.pagespeed.gp+jp+jw+pj+ws+js+rj+rp+rw+ri+cp+md.ic._UP16ehHUH.png)
