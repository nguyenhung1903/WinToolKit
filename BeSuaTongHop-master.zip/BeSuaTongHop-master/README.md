# BeSuaTongHop
# Chào mừng các bạn đến với Github của mình. Mình có 1 số lưu ý ở dưới mong các bạn đọc.

Lưu ý:
* Mỗi nội dung folder sẽ có hướng dẫn cụ thể, các bạn hãy đọc file readme.md.
* Các file mình sẽ lưu cả trên GitHub.com và Upload.ee (Có vài nội dung mình sẽ có link Goolge Drive) cho nên nếu bạn nào biết cách làm thì chỉ cần mở file trên GitHub và copy, còn không thì hãy tải về theo link mình để trong từng file readme.md
* Vì đây là lần đầu mình dùng GitHub cho nên các bạn sẽ thấy cách mình làm việc với nó chưa tối ưu lắm, mong các bạn thông cảm.
* Các folder trống đang được update dần, các bạn hãy kiên nhẫn.
* Các nội dung có đụng đến registry, các bạn hãy backup lại registry trước khi thực hiện nhé, chỉ để đề phòng thôi.
