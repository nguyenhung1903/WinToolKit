# Cách Thêm Windows Photo Viewer vào Windows 10

Bắt đầu từ Windows 10, Microsoft dường như đã loại bỏ Windows Photo Viewer thay bằng app Photos. Tuy nhiên nhiều người vẫn thích trình xem cũ hơn, sau đây là cách thêm Windows Photo Viewer.

Các bạn chỉ cần tải file dưới về và chạy là được, khi đó Windows Photo Viewer sẽ được thêm.

Link Download Add (Cho ai muốn cài): [Download Now](https://www.upload.ee/files/12104499/Activate_Windows_Photo_Viewer_on_Windows_10.reg.html)

Link Download Remove (Cho ai muốn gỡ): [Download Now](https://www.upload.ee/files/12104500/Deactivate_Windows_Photo_Viewer_on_Windows_10.reg.html)

![Image](https://www.howtogeek.com/wp-content/uploads/2017/03/wpv_3.png)
