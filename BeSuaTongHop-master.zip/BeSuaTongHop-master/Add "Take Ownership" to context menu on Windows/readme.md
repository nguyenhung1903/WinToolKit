# Thêm "Take Ownership" vào menu chuột phải trên Windows

Như cái tên gọi của nó - chiếm quyền sở hữu. "Take Ownership" là cấp phép quyền quản trị đầy đủ đối với tập tin, thư mục, ổ đĩa… giúp bạn có thể chỉnh sửa những file thư mục mà hệ thống không cho phép quyền bình thường được quản trị.

Các bạn chỉ cần tải file dưới về chạy là được:

Link Download Add (Link này dành cho ai muốn thêm): [Download Now](https://www.upload.ee/files/12103427/Take_Ownership_-_Install.reg.html)

Link Download Remove (Link này dành cho ai muốn gỡ bỏ): [Download Now](https://www.upload.ee/files/12103428/Take_Ownership_-_Uninstall.reg.html)

![Take Ownership](https://i.imgur.com/vJo8PuT.jpg)
