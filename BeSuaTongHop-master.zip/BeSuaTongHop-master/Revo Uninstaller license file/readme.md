# Hướng dẫn sử dụng file License để kích hoạt Revo Uninstaller Pro

Revo Uninstaller là phần mềm gỡ bỏ các ứng dụng cứng đầu hoặc không còn sử dụng nữa một cách sạch sẽ. Sau đây là cách sử dụng file License:

Bước 1: Tải về file License: [Download File License](https://www.upload.ee/files/12103371/revouninstallerpro4.lic.html)

Bước 2: Copy file vừa tải về vào đường dẫn "C:\ProgramData\VS Revo Group\Revo Uninstaller Pro"

# Cách đổi tên phần Registered to ....

Bước 1: Tải về file reg: [Download File Reg](https://www.upload.ee/files/12103370/Rename_Registered_To_Revo_Uninstaller.reg.html)

Bước 2: Chuột phải file vừa tải về, chọn "Edit", thay phần "VS Revo Group" thành tên bạn thích, lưu lại và chạy.

![Revo](https://i.imgur.com/QXFThMq.png)
